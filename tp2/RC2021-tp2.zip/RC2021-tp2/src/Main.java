
public class Main {

	public static void main(String[] args ) {
		cnss.simulator.Simulator.main(new String[] { "configs/config-2.1.txt"});
	}
}
