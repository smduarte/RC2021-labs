package udp;

import java.io.*;
import java.net.*;

public class FileSenderClient {


	static void sendFile(InetSocketAddress server, String filename) {

		int n;
		byte[] buffer = new byte[FileSenderServer.BLOCK_SIZE];

		try (DatagramSocket socket = new DatagramSocket(); FileInputStream fis = new FileInputStream(filename)) {

			// TO DO
			
		} catch (IOException x) {
			x.printStackTrace();
		}
	}

	public static void main(String[] args) {
		if (args.length != 3) {
			System.err.println("usage: <server> <port> <filename>");
			System.exit(0);
		}

		String host = args[0];
		String filename = args[2];
		int port = Integer.valueOf(args[1]);

		InetSocketAddress server = new InetSocketAddress(host, port);
		sendFile(server, filename);
	}
}
